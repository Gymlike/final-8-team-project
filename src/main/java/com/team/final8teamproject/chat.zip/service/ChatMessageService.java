package com.team.final8teamproject.chat.service;


import com.team.final8teamproject.chat.dto.ChatMessageDto;

public interface ChatMessageService {

  ChatMessageDto createChat(ChatMessageDto message, Long roomId);
}
