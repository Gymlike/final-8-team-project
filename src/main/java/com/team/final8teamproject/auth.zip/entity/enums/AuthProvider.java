package com.team.final8teamproject.auth.entity.enums;

public enum AuthProvider {
    KAKAO,
    ;
}
