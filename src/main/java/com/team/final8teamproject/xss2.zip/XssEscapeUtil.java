package com.team.final8teamproject.xss;

import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.stereotype.Component;

import java.util.regex.Pattern;
@Component
public class XssEscapeUtil {

    private static final Pattern[] patterns = new Pattern[]{
            // script tag
            Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE),
            // src='...'
            Pattern.compile("src[\r\n]*=[\r\n]*'(.*?)'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // src="..."
            Pattern.compile("src[\r\n]*=[\r\n]*\"(.*?)\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // eval(...)
            Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // expression(...)
            Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // javascript:...
            Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE),
            // vbscript:...
            Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE),
            // onload(...)=...
            Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL)
    };

    /**
     * HTML 태그 제거와 XSS 방지 처리를 수행한다.
     *
     * @param str XSS 방지 처리할 문자열
     * @return XSS 방지 처리된 문자열
     */
    public static String escape(String str) {
        if (str == null || str.trim().isEmpty()) {
            return str;
        }

        String escaped = StringEscapeUtils.escapeHtml3(str);
        for (Pattern pattern : patterns) {
            escaped = pattern.matcher(escaped).replaceAll("");
        }

        return escaped;
    }
}
