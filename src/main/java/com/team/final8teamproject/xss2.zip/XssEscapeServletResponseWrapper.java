package com.team.final8teamproject.xss;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.WriteListener;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class XssEscapeServletResponseWrapper extends HttpServletResponseWrapper {

    private final XssEscapeUtil xssEscapeUtil;
    private final XssEscapeServletOutputStreamWrapper outputStreamWrapper;
    private PrintWriter writer;

    public XssEscapeServletResponseWrapper(HttpServletResponse response, XssEscapeUtil xssEscapeUtil) throws IOException {
        super(response);
        this.xssEscapeUtil = xssEscapeUtil;
        outputStreamWrapper = new XssEscapeServletOutputStreamWrapper(response.getOutputStream(), xssEscapeUtil);
    }

    @Override
    public ServletOutputStream getOutputStream() throws IOException {
        return outputStreamWrapper;
    }

    @Override
    public PrintWriter getWriter() throws IOException {
        if (writer == null) {
            writer = new PrintWriter(new OutputStreamWriter(outputStreamWrapper, getCharacterEncoding()));
        }
        return writer;
    }

    @Override
    public void flushBuffer() throws IOException {
        if (writer != null) {
            writer.flush();
        }
        outputStreamWrapper.flush();
        super.flushBuffer();
    }

    @Override
    public String getContentType() {
        String contentType = super.getContentType();
        if (contentType != null && !contentType.contains("charset")) {
            contentType += ";charset=UTF-8";
        }
        return contentType;
    }

    private static class XssEscapeServletOutputStreamWrapper extends ServletOutputStream {

        private final ServletOutputStream outputStream;
        private final XssEscapeUtil xssEscapeUtil;

        public XssEscapeServletOutputStreamWrapper(ServletOutputStream outputStream, XssEscapeUtil xssEscapeUtil) {
            this.outputStream = outputStream;
            this.xssEscapeUtil = xssEscapeUtil;
        }

        @Override
        public void write(int b) throws IOException {
            outputStream.write(b);
        }

        @Override
        public void write(byte[] b) throws IOException {
            outputStream.write(b);
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            String escaped = xssEscapeUtil.escape(new String(b, off, len));
            outputStream.write(escaped.getBytes());
        }

        @Override
        public void flush() throws IOException {
            outputStream.flush();
        }

        @Override
        public void close() throws IOException {
            outputStream.close();
        }

        @Override
        public boolean isReady() {
            return false;
        }

        @Override
        public void setWriteListener(WriteListener listener) {

        }
    }
}
