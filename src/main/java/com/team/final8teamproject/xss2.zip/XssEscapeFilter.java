package com.team.final8teamproject.xss;

import jakarta.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
@RequiredArgsConstructor
public class XssEscapeFilter implements Filter {

    private final Logger logger = LoggerFactory.getLogger(XssEscapeFilter.class);

    private final XssEscapeUtil xssEscapeUtil;


    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain)
            throws IOException, ServletException {
        if (!(request instanceof HttpServletRequest)) {
            chain.doFilter(request, response);
            return;
        }
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        XssEscapeServletFilterWrapper wrappedRequest = new XssEscapeServletFilterWrapper(req);
        XssEscapeServletResponseWrapper wrappedResponse =
                new XssEscapeServletResponseWrapper(res, xssEscapeUtil);
        chain.doFilter(wrappedRequest, wrappedResponse);

        String result = wrappedResponse.toString();
        result = xssEscapeUtil.escape(result);

        PrintWriter out = response.getWriter();
        out.write(result);
        out.flush();
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        logger.info("XssEscapeFilter initialized.");
    }

    @Override
    public void destroy() {
        logger.info("XssEscapeFilter destroyed.");
    }
}
