package com.team.final8teamproject.xss.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.team.final8teamproject.xss.XssEscapeUtil;
import com.team.final8teamproject.xss.XssEscapeFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

@Configuration
public class XssFilterConfig {
    private final ObjectMapper objectMapper;
    private final XssEscapeUtil xssEscapeUtil;

    public XssFilterConfig(ObjectMapper objectMapper, XssEscapeUtil xssEscapeUtil) {
        this.objectMapper = objectMapper;
        this.xssEscapeUtil= xssEscapeUtil;
    }

    //Lucy Xss filter 적용
    /**
     * RequestBoy 형태의 xss공격이 들어왔을때 잡아주기 위한
     * Filter
     * 변환 메소드
     *
//     */
//    @Bean
//    public FilterRegistrationBean<XssEscapeFilter> xssFilterBean(){
//        FilterRegistrationBean<XssEscapeFilter> registrationBean = new FilterRegistrationBean<>();
//        registrationBean.setFilter(new XssEscapeFilter(xssEscapeUtil));
//        registrationBean.setOrder(Ordered.LOWEST_PRECEDENCE);
//        registrationBean.addUrlPatterns("/*");
//        return registrationBean;
//    }
//
//    //requestBody xss 필터 적용(json/api)
//
//    /**
//     * LocalDateTime 왔을때 변환해주기 위한
//     * 컨버터 메소드
//     * @return
//     */
//    @Bean
//    public MappingJackson2HttpMessageConverter jsonEscapeConverter() {
//        ObjectMapper copy = objectMapper.copy();
//        copy.getFactory().setCharacterEscapes(new HtmlCharacterEscapes());
//        return new MappingJackson2HttpMessageConverter(copy);
//    }

}
