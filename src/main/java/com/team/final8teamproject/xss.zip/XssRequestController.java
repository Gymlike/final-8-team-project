package com.team.final8teamproject.xss;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class XssRequestController {

    @PostMapping(value = "/xss", produces = MediaType.APPLICATION_JSON_VALUE)
    public XssRequestDto xss (@RequestBody XssRequestDto xssRequestDto) {
        log.info("requestDto={}", xssRequestDto);

        return xssRequestDto;
    }
}