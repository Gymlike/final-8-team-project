package com.team.final8teamproject.xss;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.jetbrains.annotations.NotNull;
import org.springframework.web.servlet.HandlerInterceptor;

public class XSSFilterInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request,
                             @NotNull HttpServletResponse response,
                             @NotNull Object handler) throws Exception {
        if ("POST".equalsIgnoreCase(request.getMethod())) {
            // RequestBody의 XSS 공격 방지 처리
            request.setAttribute("XSS_REQUEST_WRAPPER", new XSSRequestWrapper(request));
        }

        return true;
    }

}
