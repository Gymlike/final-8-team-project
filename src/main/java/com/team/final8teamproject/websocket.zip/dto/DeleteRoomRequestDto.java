package com.team.final8teamproject.websocket.dto;

import lombok.Getter;

@Getter
public class DeleteRoomRequestDto {
    private String ownerNickName;
    private String roomTitle;
}
