package com.team.final8teamproject.websocket.dto;

import lombok.Getter;

@Getter
public class CreateRoomRequestDto {
    private String ownerNickName;
    private String userNickName;
}
