package com.team.final8teamproject.websocket.dto;

public class GetMyRoomRequestDto {
    private String userNickName;

    public String getUserNickName(){
        return this.userNickName;
    }
}
